
import time

while True:
    print("ShadowTact v1.3 雲端系統啟動中...")
    time.sleep(60)
